package 평섭과건희;

import java.util.ArrayList;
import java.util.List;

public class VideoReviewDaoImpl implements IVideoReviewDao {
	private static List<VideoReview>commentList = new ArrayList<>();
	
	private static IVideoReviewDao reviewManager= new VideoReviewDaoImpl();
	
	private VideoReviewDaoImpl() {
		
	}

	public static IVideoReviewDao getInstance() {
		// TODO Auto-generated method stub
		return reviewManager;
	}
	
	@Override
	public int insertReview(VideoReview videoReview) {
		//commentList를 돌면서 videoReview의 아이디와 겹치는 아이디가 있는지 확인한다.
		
		commentList.add(videoReview);
		return 0;
	}

	@Override
	public List<VideoReview> selectReview(int videoNo) {
		List<VideoReview> returnList = new ArrayList<>();
		for(VideoReview vr : commentList) {
			if(vr.getVideoNo() == videoNo) {
				returnList.add(vr);
			}
		}
		if(returnList.size()==0) {
			return null;
		}
		return returnList;
	}

	
}
