CREATE SCHEMA ssafy_test;

USE ssafy_campus;

-- 영상정보A 
CREATE TABLE IF NOT EXISTS `video_info` (
    -- 기본 키는 id
    `videoid` VARCHAR(50) NOT null PRIMARY KEY,
    `exercise_area` VARCHAR(10) NOT NULL,
    `view_cnt` int NOT NULL,
    `video_link` VARCHAR(200) not null
) ENGINE = InnoDB;


-- 영상 리뷰
CREATE TABLE IF NOT EXISTS `video_review` (
    `reviewid` VARCHAR(30) NOT NULL  PRIMARY KEY,
    `videoid` VARCHAR(50) NOT NULL,
    `content` VARCHAR(50) NOT NULL,
    `like`  int ,
     FOREIGN KEY (`videoid`) REFERENCES `video_info` (`videoid`)
) ENGINE = InnoDB;


--  회원 정보
CREATE TABLE IF NOT EXISTS `user_info` (
    
    `userid` VARCHAR(30) NOT NULL  PRIMARY KEY,
    `password` varchar(20) NOT NULL,
    `name` VARCHAR(20) NOT NULL,
	`gender` VARCHAR(10) NOT NULL,
	`email` VARCHAR(100) NOT NULl,
	`age` int 
  
) ENGINE = InnoDB;


-- 회원 찜 
CREATE TABLE IF NOT EXISTS `user_zzim` (
     `zzimid` VARCHAR(30) PRIMARY key,
     `userid` VARCHAR(30) NOT NULL ,
   FOREIGN KEY (`userid`) REFERENCES `user_info` (`userid`)
) ENGINE = InnoDB;

-- 회원 친구 
CREATE TABLE IF NOT EXISTS `user_friend` (
   `friendid` VARCHAR(30) PRIMARY key,
	`userid` VARCHAR(30) NOT NULL ,
     FOREIGN KEY (`userid`) REFERENCES `user_info` (`userid`)
) ENGINE = InnoDB;
