package 평섭과건희;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;

import com.google.gson.Gson;

public class SsafitApplication {
	static int num = 1;
	public static void main(String[] args) throws IOException {
		IVideoDao vm = VideoDaoImpl.getInstance();
		IVideoReviewDao iv = VideoReviewDaoImpl.getInstance();
		boolean continueBtn = true;
		Scanner sc = new Scanner(System.in);
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("src/평섭과건희/video.json")));
		StringBuilder sb = new StringBuilder();
		String str = null;
		while ((str = br.readLine()) != null) {
			sb.append(str).append("\n");
		}
		Gson gson = new Gson();
		Video[] arr = gson.fromJson(sb.toString(), Video[].class);
		for (int i = 0; i < arr.length; i++) {
			vm.addVideo(arr[i]);
		}
		while (continueBtn) {
			System.out.println("==============================");
			System.out.println("===== 자바로 구현하는 SSAFIT ======");
			System.out.println("==============================");
			System.out.println("1. 영 상 목 록");
			System.out.println("0. 종 료");
			System.out.print("원하는 기능을 선택하세요: ");

			int choice = sc.nextInt();
			sc.nextLine(); // 버퍼 비우기

			switch (choice) {
			case 0:
				System.out.println("프로그램을 종료합니다.");
				sc.close(); // Scanner 사용 종료
				continueBtn = false;
				return;
			case 1:
				// 영상목록 기능
				List<Video> select = vm.selectVideo();
				for (Video el : select) {
					System.out.println(el);
				}
				videoMenu(sc, vm, iv);
				break;
			default:
				System.out.println("올바른 메뉴 번호를 입력해주세요.");
				break;
			}
		}
	}

	private static void videoMenu(Scanner sc, IVideoDao vm, IVideoReviewDao iv) {
		while (true) {
			System.out.println("==============================");
			System.out.println("1. 영 상 상 세");
			System.out.println("0. 이 전 으 로");
			System.out.println("==============================");
			System.out.print("메뉴를 선택하세요 : ");

			int choice = sc.nextInt();
			sc.nextLine(); // 버퍼 비우기

			switch (choice) {
			case 0:
				System.out.println("이전 메뉴로 돌아갑니다.");
				return;
			// 기능들이 복잡해지기 때문에 코드 가독성을 위해서 모듈화 처리를 해 분리한다.
			case 1:
				System.out.print("영상번호를 입력하세요 : ");
				int videoNum = sc.nextInt();
				vm.selectVideoByConsole(videoNum);
				videoCommentMenu(sc, videoNum, vm, iv);
				break;
			default:
				System.out.println("올바른 메뉴 번호를 입력해주세요.");
				break;
			}
		}

	}

	public static void videoCommentMenu(Scanner sc, int videoNum, IVideoDao vm, IVideoReviewDao iv) {
		List<VideoReview> instantArr =  iv.selectReview(videoNum);
		if (iv.selectReview(videoNum) != null) {
			System.out.printf("리뷰 개수: %d개\n", instantArr.size());
			System.out.println(iv.selectReview(videoNum));
		}
		//그냥 여기서 받아가지고 리스트로 받아 나와라
		//왜냐 받아놓은 리스트의 길이를 출력하고
		//null 체크도 한번에
		System.out.println("==============================");
		System.out.println("1. 리 뷰 등 록");
		System.out.println("0. 이 전 으 로");
		System.out.println("==============================");
		System.out.print("메뉴를 선택하세요 : ");
		int choice = sc.nextInt();
		sc.nextLine();

		switch (choice) {
		case 0:
			System.out.println("이전 메뉴로 돌아갑니다.");
			return;
		case 1:
			System.out.print("닉네임을 입력하세요 : ");
			String nickname = sc.nextLine();
			System.out.print("댓글을 입력하세요 : ");
			String comment = sc.nextLine();
			VideoReview review = new VideoReview(videoNum, num++, nickname, comment);

			iv.insertReview(review);
			break;
		default:
			break;

		}
	}

}
