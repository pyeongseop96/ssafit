package com.ssafit.board;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPjtSsafit6thApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPjtSsafit6thApplication.class, args);
	}

}
