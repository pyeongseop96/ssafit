package 평섭과건희;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class VideoDaoImpl implements IVideoDao {

	private static List<Video> videoList = new ArrayList<>();

	private static IVideoDao videoManager = new VideoDaoImpl();

	private VideoDaoImpl() {
	}

	public static IVideoDao getInstance() {
		return videoManager;
	}

	@Override
	public List<Video> selectVideo() {
		return videoList;
	}

	@Override
	public Video selectVideoByNo(int no) {
		// 보고 싶은 숫자를 받았다.
		// 그 번호를 배열리스트에서 있는지를 검색
		// 반복문을 돌려서 no가 저 no인지 비교를 해보자
		// int니까 바로 == 비교해보자
		for (Video el : videoList) {
			if (el.getNo() == no) {
				return el;
			}
		}
		return null;
	}

	@Override
	public void addVideo(Video video) {

		int videoNo = video.getNo();
		for (int i = 0; i < videoList.size(); i++) {
			if (videoList.get(i).getNo() == videoNo) {
				// 에러처리
			}
		}
		videoList.add(video);
	}

	@Override
	public void selectVideoByConsole(int no) {
		for (Video el : videoList) {
			if (el.getNo() == no) {
				System.out.println("==============================");
				System.out.printf("번호 : %d\n", el.getNo());
				System.out.printf("제목 : %s\n", el.getTitle());
				System.out.printf("운동 : %s\n", el.getPart());
				System.out.printf("영상url : %s\n", el.getUrl());

			}
		}

	}

}
