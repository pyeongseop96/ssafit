package 평섭과건희;

public class Video {
	private int no;
	private String title;
	private String part;
	private String url;

	private Video() {
	}
	public Video(int no, String title, String part, String url) {
		super();
		this.no = no;
		this.title = title;
		this.part = part;
		this.url = url;
	}
	public int getNo() {
		return no;
	}
	public String getTitle() {
		return title;
	}
	public String getPart() {
		return part;
	}
	public String getUrl() {
		return url;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setPart(String part) {
		this.part = part;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	@Override
	public String toString() {
		return String.format("%d   %s  %s", no,part,title);
	}
	
	
	
}
