package 평섭과건희;

import java.util.List;

public interface IVideoDao {
	public List<Video> selectVideo();
	
	public Video selectVideoByNo(int no);
	
	public void addVideo(Video video);
	
	public void selectVideoByConsole(int no);
}
