package 평섭과건희;

import java.util.List;

public interface IVideoReviewDao {
	public int insertReview(VideoReview videoReview);
	
	public List<VideoReview> selectReview(int videoNo);
}
